#!/bin/bash
rm *data.txt
rm *tex
rm *~
rm *compare\.*
rm sum*txt
rm all*txt
rm all*list
