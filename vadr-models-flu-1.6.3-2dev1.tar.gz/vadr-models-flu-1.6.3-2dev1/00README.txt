December 2023
vadr-models-flu-1.6.3-1

https://github.com/ncbi/vadr

VADR documentation:
https://github.com/ncbi/vadr/blob/master/README.md

See RELEASE-NOTES.txt for details on changes between model versions. 
See 00NOTES.txt for additional information on the models.

------------

Recommended command for flu annotation using vadr v1.6.3
(as of December 18, 2023) but still under testing and subject to 
change.

v-annotate.pl \
--split --cpu 8 -r \
--atgonly --xnocomp --nomisc \
--alt_fail extrant5,extrant3 \
--mkey flu \
--mdir <PATH-TO-THIS-MODEL-DIR> \
<fastafile> <outputdir>

The '--split --cpu 8' options will run v-annotate.pl multi-threaded on
8 threads. To change to '<n>' threads use '--split --cpu <n>', but
make sure you have <n> * 2G total RAM available. 

To run single threaded remove the '--split --cpu 8' options.

--

Contact eric.nawrocki@nih.gov for help.
