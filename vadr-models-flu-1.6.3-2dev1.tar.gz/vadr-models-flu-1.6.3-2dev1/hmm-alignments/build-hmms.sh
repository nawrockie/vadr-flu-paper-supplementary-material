$VADRHMMERDIR/hmmbuild -n AY191501/47..349:+ AY191501.47..349.protein.hmm AY191501.47..349.protein.fa
$VADRHMMERDIR/hmmbuild -n AY504605/25..771:+ AY504605.25..771.protein.hmm AY504605.25..771.protein.fa
$VADRHMMERDIR/hmmbuild -n AY504605/768..1100:+ AY504605.768..1100.protein.hmm AY504605.768..1100.protein.fa
$VADRHMMERDIR/hmmbuild -n AY684891/34..1734:+ AY684891.34..1734.protein.hmm AY684891.34..1734.protein.fa
$VADRHMMERDIR/hmmbuild -n CY002009/26..51:+,740..1004:+ CY002009.26..51,740..1004.protein.hmm CY002009.26..51,740..1004.protein.fa
$VADRHMMERDIR/hmmbuild -n CY002010/20..1426:+ CY002010.20..1426.protein.hmm CY002010.20..1426.protein.fa
$VADRHMMERDIR/hmmbuild -n CY002079/28..2313:+ CY002079.28..2313.protein.hmm CY002079.28..2313.protein.fa
$VADRHMMERDIR/hmmbuild -n CY002284/27..740:+ CY002284.27..740.protein.hmm CY002284.27..740.protein.fa
$VADRHMMERDIR/hmmbuild -n CY002284/27..713:+ CY002284.27..713.protein.hmm CY002284.27..713.protein.fa
$VADRHMMERDIR/hmmbuild -n CY002284/27..689:+ CY002284.27..689.protein.hmm CY002284.27..689.protein.fa
$VADRHMMERDIR/hmmbuild -n CY002284/27..701:+ CY002284.27..701.protein.hmm CY002284.27..701.protein.fa
$VADRHMMERDIR/hmmbuild -n CY002284/27..686:+ CY002284.27..686.protein.hmm CY002284.27..686.protein.fa
$VADRHMMERDIR/hmmbuild -n CY002284/27..743:+ CY002284.27..743.protein.hmm CY002284.27..743.protein.fa
$VADRHMMERDIR/hmmbuild -n CY002284/27..698:+ CY002284.27..698.protein.hmm CY002284.27..698.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003645/25..594:+,596..724:+ CY003645.25..594,596..724.protein.hmm CY003645.25..594,596..724.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003646/119..382:+ CY003646.119..382.protein.hmm CY003646.119..382.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003646/119..358:+ CY003646.119..358.protein.hmm CY003646.119..358.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003646/119..292:+ CY003646.119..292.protein.hmm CY003646.119..292.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003646/119..298:+ CY003646.119..298.protein.hmm CY003646.119..298.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003646/119..424:+ CY003646.119..424.protein.hmm CY003646.119..424.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003646/119..310:+ CY003646.119..310.protein.hmm CY003646.119..310.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003646/233..391:+ CY003646.233..391.protein.hmm CY003646.233..391.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003646/119..355:+ CY003646.119..355.protein.hmm CY003646.119..355.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003646/119..289:+ CY003646.119..289.protein.hmm CY003646.119..289.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003646/119..364:+ CY003646.119..364.protein.hmm CY003646.119..364.protein.fa
$VADRHMMERDIR/hmmbuild -n CY003646/119..349:+ CY003646.119..349.protein.hmm CY003646.119..349.protein.fa
$VADRHMMERDIR/hmmbuild -n CY004056/21..1433:+ CY004056.21..1433.protein.hmm CY004056.21..1433.protein.fa
$VADRHMMERDIR/hmmbuild -n CY004435/23..1435:+ CY004435.23..1435.protein.hmm CY004435.23..1435.protein.fa
$VADRHMMERDIR/hmmbuild -n CY005359/22..1434:+ CY005359.22..1434.protein.hmm CY005359.22..1434.protein.fa
$VADRHMMERDIR/hmmbuild -n CY005970/20..1721:+ CY005970.20..1721.protein.hmm CY005970.20..1721.protein.fa
$VADRHMMERDIR/hmmbuild -n CY006034/22..1734:+ CY006034.22..1734.protein.hmm CY006034.22..1734.protein.fa
$VADRHMMERDIR/hmmbuild -n CY103881/28..2310:+ CY103881.28..2310.protein.hmm CY103881.28..2310.protein.fa
$VADRHMMERDIR/hmmbuild -n CY103882/27..2297:+ CY103882.27..2297.protein.hmm CY103882.27..2297.protein.fa
$VADRHMMERDIR/hmmbuild -n CY103883/23..2164:+ CY103883.23..2164.protein.hmm CY103883.23..2164.protein.fa
$VADRHMMERDIR/hmmbuild -n CY103884/35..1729:+ CY103884.35..1729.protein.hmm CY103884.35..1729.protein.fa
$VADRHMMERDIR/hmmbuild -n CY103885/41..1534:+ CY103885.41..1534.protein.hmm CY103885.41..1534.protein.fa
$VADRHMMERDIR/hmmbuild -n CY103886/24..1352:+ CY103886.24..1352.protein.hmm CY103886.24..1352.protein.fa
$VADRHMMERDIR/hmmbuild -n CY103887/24..49:+,738..1002:+ CY103887.24..49,738..1002.protein.hmm CY103887.24..49,738..1002.protein.fa
$VADRHMMERDIR/hmmbuild -n CY103887/24..782:+ CY103887.24..782.protein.hmm CY103887.24..782.protein.fa
$VADRHMMERDIR/hmmbuild -n CY103888/28..60:+,536..871:+ CY103888.28..60,536..871.protein.hmm CY103888.28..60,536..871.protein.fa
$VADRHMMERDIR/hmmbuild -n CY103888/28..693:+ CY103888.28..693.protein.hmm CY103888.28..693.protein.fa
$VADRHMMERDIR/hmmbuild -n CY125942/28..2310:+ CY125942.28..2310.protein.hmm CY125942.28..2310.protein.fa
$VADRHMMERDIR/hmmbuild -n CY125943/27..2297:+ CY125943.27..2297.protein.hmm CY125943.27..2297.protein.fa
$VADRHMMERDIR/hmmbuild -n CY125944/23..2164:+ CY125944.23..2164.protein.hmm CY125944.23..2164.protein.fa
$VADRHMMERDIR/hmmbuild -n CY125945/29..1714:+ CY125945.29..1714.protein.hmm CY125945.29..1714.protein.fa
$VADRHMMERDIR/hmmbuild -n CY125946/41..1534:+ CY125946.41..1534.protein.hmm CY125946.41..1534.protein.fa
$VADRHMMERDIR/hmmbuild -n CY125947/24..1367:+ CY125947.24..1367.protein.hmm CY125947.24..1367.protein.fa
$VADRHMMERDIR/hmmbuild -n CY125948/24..49:+,738..1002:+ CY125948.24..49,738..1002.protein.hmm CY125948.24..49,738..1002.protein.fa
$VADRHMMERDIR/hmmbuild -n CY125948/24..782:+ CY125948.24..782.protein.hmm CY125948.24..782.protein.fa
$VADRHMMERDIR/hmmbuild -n CY125949/28..60:+,536..871:+ CY125949.28..60,536..871.protein.hmm CY125949.28..60,536..871.protein.fa
$VADRHMMERDIR/hmmbuild -n CY125949/28..693:+ CY125949.28..693.protein.hmm CY125949.28..693.protein.fa
$VADRHMMERDIR/hmmbuild -n GM968017/1..1968:+ GM968017.1..1968.protein.hmm GM968017.1..1968.protein.fa
$VADRHMMERDIR/hmmbuild -n GM968018/1..2130:+ GM968018.1..2130.protein.hmm GM968018.1..2130.protein.fa
$VADRHMMERDIR/hmmbuild -n GM968019/1..2265:+ GM968019.1..2265.protein.hmm GM968019.1..2265.protein.fa
$VADRHMMERDIR/hmmbuild -n GN364866/1..2325:+ GN364866.1..2325.protein.hmm GN364866.1..2325.protein.fa
$VADRHMMERDIR/hmmbuild -n M35997/18..1724:+ M35997.18..1724.protein.hmm M35997.18..1724.protein.fa
$VADRHMMERDIR/hmmbuild -n NC_006311/30..1727:+ NC_006311.30..1727.protein.hmm NC_006311.30..1727.protein.fa
$VADRHMMERDIR/hmmbuild -n NC_036615/26..2287:+ NC_036615.26..2287.protein.hmm NC_036615.26..2287.protein.fa
$VADRHMMERDIR/hmmbuild -n NC_036616/15..2333:+ NC_036616.15..2333.protein.hmm NC_036616.15..2333.protein.fa
$VADRHMMERDIR/hmmbuild -n NC_036617/28..1686:+ NC_036617.28..1686.protein.hmm NC_036617.28..1686.protein.fa
$VADRHMMERDIR/hmmbuild -n NC_036618/25..2019:+ NC_036618.25..2019.protein.hmm NC_036618.25..2019.protein.fa
$VADRHMMERDIR/hmmbuild -n NC_036619/23..2155:+ NC_036619.23..2155.protein.hmm NC_036619.23..2155.protein.fa
$VADRHMMERDIR/hmmbuild -n NC_036620/29..1192:+ NC_036620.29..1192.protein.hmm NC_036620.29..1192.protein.fa
$VADRHMMERDIR/hmmbuild -n NC_036621/29..218:+,484..848:+ NC_036621.29..218,484..848.protein.hmm NC_036621.29..218,484..848.protein.fa
$VADRHMMERDIR/hmmbuild -n NC_036621/29..760:+ NC_036621.29..760.protein.hmm NC_036621.29..760.protein.fa
$VADRHMMERDIR/hmmbuild -n ON637239/1..1686:+ ON637239.1..1686.protein.hmm ON637239.1..1686.protein.fa
$VADRHMMERDIR/hmmbuild --hand -n AF387493/34..1788:+ AF387493.34..1788.protein.hmm AF387493.34..1788.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n AY191501/54..1454:+ AY191501.54..1454.protein.hmm AY191501.54..1454.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n AY504599/24..2336:+ AY504599.24..2336.protein.hmm AY504599.24..2336.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n AY504605/771..1100:+ AY504605.771..1100.protein.hmm AY504605.771..1100.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n AY504614/44..76:+,732..1067:+ AY504614.44..76,732..1067.protein.hmm AY504614.44..76,732..1067.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n AY504614/44..889:+ AY504614.44..889.protein.hmm AY504614.44..889.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY000449/33..1733:+ CY000449.33..1733.protein.hmm CY000449.33..1733.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY002000/30..1730:+ CY002000.30..1730.protein.hmm CY002000.30..1730.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY002009/26..51:+,740..1007:+ CY002009.26..51,740..1007.protein.hmm CY002009.26..51,740..1007.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY002009/26..784:+ CY002009.26..784.protein.hmm CY002009.26..784.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY002010/20..1429:+ CY002010.20..1429.protein.hmm CY002010.20..1429.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY002079/28..2307:+ CY002079.28..2307.protein.hmm CY002079.28..2307.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY002284/27..56:+,529..864:+ CY002284.27..56,529..864.protein.hmm CY002284.27..56,529..864.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY002284/27..719:+ CY002284.27..719.protein.hmm CY002284.27..719.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY002284/27..680:+ CY002284.27..680.protein.hmm CY002284.27..680.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY002284/27..710:+ CY002284.27..710.protein.hmm CY002284.27..710.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY002538/21..1433:+ CY002538.21..1433.protein.hmm CY002538.21..1433.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY003645/25..2175:+ CY003645.25..2175.protein.hmm CY003645.25..2175.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY003645/25..594:+,596..784:+ CY003645.25..594,596..784.protein.hmm CY003645.25..594,596..784.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY003646/119..391:+ CY003646.119..391.protein.hmm CY003646.119..391.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY003646/25..2298:+ CY003646.25..2298.protein.hmm CY003646.25..2298.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY003646/25..2301:+ CY003646.25..2301.protein.hmm CY003646.25..2301.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY003907/44..1732:+ CY003907.44..1732.protein.hmm CY003907.44..1732.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY004131/19..1431:+ CY004131.19..1431.protein.hmm CY004131.19..1431.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY004429/21..1442:+ CY004429.21..1442.protein.hmm CY004429.21..1442.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY004642/34..1716:+ CY004642.34..1716.protein.hmm CY004642.34..1716.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY004847/20..1714:+ CY004847.20..1714.protein.hmm CY004847.20..1714.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY005641/19..1431:+ CY005641.19..1431.protein.hmm CY005641.19..1431.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY005890/19..1428:+ CY005890.19..1428.protein.hmm CY005890.19..1428.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY005970/20..1720:+ CY005970.20..1720.protein.hmm CY005970.20..1720.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY005979/41..1741:+ CY005979.41..1741.protein.hmm CY005979.41..1741.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY006001/20..1705:+ CY006001.20..1705.protein.hmm CY006001.20..1705.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY006005/33..1730:+ CY006005.33..1730.protein.hmm CY006005.33..1730.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY006008/20..1714:+ CY006008.20..1714.protein.hmm CY006008.20..1714.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY006037/22..1704:+ CY006037.22..1704.protein.hmm CY006037.22..1704.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n CY006079/46..1542:+ CY006079.46..1542.protein.hmm CY006079.46..1542.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n DQ376635/18..1721:+ DQ376635.18..1721.protein.hmm DQ376635.18..1721.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n DQ864721/29..1735:+ DQ864721.29..1735.protein.hmm DQ864721.29..1735.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n EF626631/61..1743:+ EF626631.61..1743.protein.hmm EF626631.61..1743.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n EF626633/30..2210:+ EF626633.30..2210.protein.hmm EF626633.30..2210.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n EF626642/22..2280:+ EF626642.22..2280.protein.hmm EF626642.22..2280.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n GM968015/1..728:+,957..957:+ GM968015.1..728,957..957.protein.hmm GM968015.1..728,957..957.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n GM968015/706..1125:+ GM968015.706..1125.protein.hmm GM968015.706..1125.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n NC_006306/27..213:+,527..888:+ NC_006306.27..213,527..888.protein.hmm NC_006306.27..213,527..888.protein.stk
$VADRHMMERDIR/hmmbuild --hand -n NC_006306/27..767:+ NC_006306.27..767.protein.hmm NC_006306.27..767.protein.stk
