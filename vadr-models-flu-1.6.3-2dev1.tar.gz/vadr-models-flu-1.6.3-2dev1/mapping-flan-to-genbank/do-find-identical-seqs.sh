perl ./find-identical-seqs.pl flan.A.nt.fa ../ncbi-virus-seqs-20230317/fluA.897490.20230317.nt.fa > flan.A.nt.id
perl ./find-identical-seqs.pl flan.B.nt.fa ../ncbi-virus-seqs-20230317/fluB.120058.20230317.nt.fa > flan.B.nt.id
perl ./find-identical-seqs.pl flan.C.nt.fa ../ncbi-virus-seqs-20230317/fluC.2475.20230317.nt.fa > flan.C.nt.id

